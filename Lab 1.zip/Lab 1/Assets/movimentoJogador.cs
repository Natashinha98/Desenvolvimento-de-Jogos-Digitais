using UnityEngine;

public class MovimentoJogador : MonoBehaviour
{
    public float velocidade = 50f;
    public float limiteY = -4.4f;
    public float limiteMinimoY = -0.5f;
    public float limiteX = 2.25f;
    public AudioSource fonteAudio;

    private Rigidbody2D corpo;

    void Start()
    {
        corpo = GetComponent<Rigidbody2D>();
        fonteAudio = GetComponent<AudioSource>();
    }

    void OnCollisionEnter2D(Collision2D colisao)
    {
        if (fonteAudio != null)
            fonteAudio.Play();
    }

    void Update()
    {
        Vector3 posicaoJogador = transform.position;
        Vector3 posicaoMouse = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        if (posicaoMouse.y > limiteMinimoY)
            posicaoMouse.y = limiteMinimoY;
        else if (posicaoMouse.y < limiteY)
            posicaoMouse.y = limiteY;

        if (posicaoMouse.x > limiteX)
            posicaoMouse.x = limiteX;
        else if (posicaoMouse.x < -limiteX)
            posicaoMouse.x = -limiteX;

        Vector3 direcao = posicaoMouse - posicaoJogador;
        direcao.Normalize();

        Vector3 vetorVelocidade = direcao * velocidade;

        Vector2 velocidadeAtual = corpo.linearVelocity;
        velocidadeAtual.x = vetorVelocidade.x;
        velocidadeAtual.y = vetorVelocidade.y;
        corpo.linearVelocity = velocidadeAtual;
    }
}
