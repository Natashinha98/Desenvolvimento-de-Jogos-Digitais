using UnityEngine;

public class MovimentoDoDisco : MonoBehaviour
{
    private Rigidbody2D corpo;

    void IniciarMovimento()
    {
        float aleatorio = Random.Range(0, 2);

        if (aleatorio < 1)
            corpo.AddForce(new Vector2(50, -15));
        else
            corpo.AddForce(new Vector2(-20, -15));
    }

    void Start()
    {
        corpo = GetComponent<Rigidbody2D>();
        Invoke("IniciarMovimento", 2f);
    }

    void OnCollisionEnter2D(Collision2D colisao)
    {
        if (colisao.collider.CompareTag("Player"))
        {
            Vector2 velocidade;
            velocidade.x = corpo.linearVelocity.x;
            velocidade.y = (corpo.linearVelocity.y / 2f) +
                             (colisao.collider.attachedRigidbody.linearVelocity.y / 3f);
            corpo.linearVelocity = velocidade;
        }
    }

    void ReiniciarDisco()
    {
        corpo.linearVelocity = Vector2.zero;
        transform.position = Vector2.zero;
    }

    void ReiniciarJogo()
    {
        ReiniciarDisco();
        CancelInvoke("IniciarMovimento");
        Invoke("IniciarMovimento", 1f);
    }
}
