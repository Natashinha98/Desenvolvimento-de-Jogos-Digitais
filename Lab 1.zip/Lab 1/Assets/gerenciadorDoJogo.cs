using UnityEngine;

public class GerenciadorDoJogo : MonoBehaviour
{
    public static int PontuacaoJogador1 = 0;
    public static int PontuacaoJogador2 = 0;

    public GUISkin temaInterface;
    private GameObject disco;

    private GUIStyle estiloPlacar;
    private GUIStyle estiloTitulo;
    private GUIStyle estiloVencedor;
    private GUIStyle estiloBotao;
    private GUIStyle estiloNomeJogador;

    private Texture2D texturaRosa;
    private Texture2D texturaAzul;
    private Texture2D texturaBranca;

    private bool jogoFinalizado = false;

    public AudioSource fonteAudio;

void Start()
{
    disco = GameObject.FindGameObjectWithTag("Ball");
    fonteAudio = GetComponent<AudioSource>();

    // FUNDO DA CÂMERA
    if (Camera.main != null)
    {
        Camera.main.clearFlags = CameraClearFlags.SolidColor;
        Camera.main.backgroundColor = new Color(1f, 0.90f, 0.95f, 1f);
    }

    // =====================================================
    // DEIXA OS GOLS VISÍVEIS POR CIMA DO FUNDO
    // =====================================================

    GameObject gol1 = GameObject.Find("GolJogador1");
    GameObject gol2 = GameObject.Find("GolJogador2");

    if (gol1 != null)
    {
        SpriteRenderer spriteGol1 = gol1.GetComponent<SpriteRenderer>();

        if (spriteGol1 != null)
        {
            // Rosa
            spriteGol1.color = new Color(1f, 0.35f, 0.70f, 1f);

            // Faz o gol aparecer na frente do fundo
            spriteGol1.sortingOrder = 10;
        }
    }

    if (gol2 != null)
    {
        SpriteRenderer spriteGol2 = gol2.GetComponent<SpriteRenderer>();

        if (spriteGol2 != null)
        {
            // Azul/turquesa
            spriteGol2.color = new Color(0.15f, 0.75f, 0.80f, 1f);

            // Faz o gol aparecer na frente do fundo
            spriteGol2.sortingOrder = 10;
        }
    }
}

    public static void MarcarPonto(string nomeGol)
    {
        if (nomeGol == "GolJogador1")
        {
            PontuacaoJogador1++;
        }
        else if (nomeGol == "GolJogador2")
        {
            PontuacaoJogador2++;
        }
    }

    private Texture2D CriarTextura(Color cor)
    {
        Texture2D textura = new Texture2D(1, 1);
        textura.SetPixel(0, 0, cor);
        textura.Apply();
        return textura;
    }

    private void CriarEstilos()
    {
        if (temaInterface == null)
        {
            Debug.LogError("Tema da interface não foi atribuído no GerenciadorDoJogo!");
            return;
        }

        if (texturaRosa == null)
            texturaRosa = CriarTextura(new Color(1f, 0.52f, 0.82f, 0.92f));

        if (texturaAzul == null)
            texturaAzul = CriarTextura(new Color(0.28f, 0.78f, 0.82f, 0.92f));

        if (texturaBranca == null)
            texturaBranca = CriarTextura(new Color(1f, 0.96f, 0.99f, 0.95f));

        // PLACAR
        if (estiloPlacar == null)
        {
            estiloPlacar = new GUIStyle(GUI.skin.label);

            estiloPlacar.alignment = TextAnchor.MiddleCenter;

            // DIMINUIDO
            estiloPlacar.fontSize = 32;

            estiloPlacar.fontStyle = FontStyle.Bold;

            estiloPlacar.normal.textColor =
                new Color(0.38f, 0.10f, 0.28f);
        }

        // NOME DOS JOGADORES
        if (estiloNomeJogador == null)
        {
            estiloNomeJogador = new GUIStyle(GUI.skin.label);

            estiloNomeJogador.alignment = TextAnchor.MiddleCenter;

            // DIMINUIDO
            estiloNomeJogador.fontSize = 13;

            estiloNomeJogador.fontStyle = FontStyle.Bold;

            estiloNomeJogador.normal.textColor = Color.white;
        }

        // TITULO
        if (estiloTitulo == null)
        {
            estiloTitulo = new GUIStyle(GUI.skin.label);

            estiloTitulo.alignment = TextAnchor.MiddleCenter;

            estiloTitulo.fontSize = 28;

            estiloTitulo.fontStyle = FontStyle.Bold;

            estiloTitulo.normal.textColor =
                new Color(0.72f, 0.20f, 0.54f);
        }

        // TEXTO DE VITORIA
        if (estiloVencedor == null)
        {
            estiloVencedor = new GUIStyle(GUI.skin.label);

            estiloVencedor.alignment = TextAnchor.MiddleCenter;

            estiloVencedor.fontSize = 42;

            estiloVencedor.fontStyle = FontStyle.Bold;

            estiloVencedor.normal.textColor =
                new Color(0.72f, 0.20f, 0.54f);
        }

        // BOTAO
        if (estiloBotao == null)
        {
            estiloBotao = new GUIStyle(GUI.skin.button);

            estiloBotao.alignment = TextAnchor.MiddleCenter;

            // DIMINUIDO
            estiloBotao.fontSize = 15;

            estiloBotao.fontStyle = FontStyle.Bold;

            estiloBotao.normal.textColor = Color.white;
            estiloBotao.hover.textColor = Color.white;
            estiloBotao.active.textColor = Color.white;

            estiloBotao.normal.background = texturaAzul;
            estiloBotao.hover.background = texturaRosa;
            estiloBotao.active.background = texturaRosa;
        }
    }

    void OnGUI()
    {
        if (temaInterface == null)
        {
            Debug.LogError(
                "Tema da interface não foi atribuído no GerenciadorDoJogo!"
            );

            return;
        }

        GUI.skin = temaInterface;

        CriarEstilos();

        // =========================================================
        // TITULO
        // =========================================================

        GUI.Label(
            new Rect(
                Screen.width / 2 - 260,
                18,
                520,
                55
            ),
            "DUELO WICKED🪄",
            estiloTitulo
        );

        // =========================================================
        // PLACAR NO LADO DIREITO
        // =========================================================

        // Tamanho dos cartões
        float larguraCartao = 105f;
        float alturaCartao = 62f;

        // Espaço entre os cartões
        float espacamento = 8f;

        // Distância da borda direita
        float margemDireita = 25f;

        // Posição horizontal
        float xPainel =
            Screen.width -
            (larguraCartao * 2) -
            espacamento -
            margemDireita;

        // Posição vertical
        float yPainel =
            Screen.height / 2f - 20f;

        // Cartão Jogador 1
        Rect cartaoJogador1 = new Rect(
            xPainel,
            yPainel,
            larguraCartao,
            alturaCartao
        );

        // Cartão Jogador 2
        Rect cartaoJogador2 = new Rect(
            xPainel + larguraCartao + espacamento,
            yPainel,
            larguraCartao,
            alturaCartao
        );

        // Fundo dos cartões
        GUI.Box(
            cartaoJogador1,
            GUIContent.none,
            CriarEstiloCartao(texturaRosa)
        );

        GUI.Box(
            cartaoJogador2,
            GUIContent.none,
            CriarEstiloCartao(texturaAzul)
        );

        // =========================================================
        // JOGADOR 1
        // =========================================================

        GUI.Label(
            new Rect(
                cartaoJogador1.x,
                cartaoJogador1.y + 2,
                larguraCartao,
                20
            ),
            "JOGADOR 1",
            estiloNomeJogador
        );

        GUI.Label(
            new Rect(
                cartaoJogador1.x,
                cartaoJogador1.y + 20,
                larguraCartao,
                40
            ),
            PontuacaoJogador1.ToString(),
            estiloPlacar
        );

        // =========================================================
        // JOGADOR 2
        // =========================================================

        GUI.Label(
            new Rect(
                cartaoJogador2.x,
                cartaoJogador2.y + 2,
                larguraCartao,
                20
            ),
            "JOGADOR 2",
            estiloNomeJogador
        );

        GUI.Label(
            new Rect(
                cartaoJogador2.x,
                cartaoJogador2.y + 20,
                larguraCartao,
                40
            ),
            PontuacaoJogador2.ToString(),
            estiloPlacar
        );

        // =========================================================
        // BOTAO REINICIAR
        // =========================================================

        float larguraBotao = 150f;
        float alturaBotao = 35f;

        float xBotao =
            Screen.width -
            larguraBotao -
            margemDireita;

        float yBotao =
            yPainel +
            alturaCartao +
            10f;

        if (GUI.Button(
            new Rect(
                xBotao,
                yBotao,
                larguraBotao,
                alturaBotao
            ),
            "REINICIAR",
            estiloBotao
        ))
        {
            PontuacaoJogador1 = 0;
            PontuacaoJogador2 = 0;

            jogoFinalizado = false;

            if (disco != null)
            {
                disco.SendMessage(
                    "ReiniciarJogo",
                    null,
                    SendMessageOptions.RequireReceiver
                );
            }
        }

        // =========================================================
        // MENSAGEM DE VITORIA
        // =========================================================

        float centro = Screen.width / 2f;

        if (PontuacaoJogador1 >= 5)
        {
            GUI.Label(
                new Rect(
                    centro - 310,
                    Screen.height / 2f - 50,
                    620,
                    100
                ),
                "JOGADOR 1 VENCEU!",
                estiloVencedor
            );

            FinalizarPartida();
        }
        else if (PontuacaoJogador2 >= 5)
        {
            GUI.Label(
                new Rect(
                    centro - 310,
                    Screen.height / 2f - 50,
                    620,
                    100
                ),
                "JOGADOR 2 VENCEU!",
                estiloVencedor
            );

            FinalizarPartida();
        }
    }

    // =============================================================
    // ESTILO DOS CARTOES
    // =============================================================

    private GUIStyle CriarEstiloCartao(Texture2D fundo)
    {
        GUIStyle estilo = new GUIStyle(GUI.skin.box);

        estilo.normal.background = fundo;

        estilo.border = new RectOffset(
            10,
            10,
            10,
            10
        );

        return estilo;
    }

    // =============================================================
    // FINALIZAR PARTIDA
    // =============================================================

    private void FinalizarPartida()
    {
        if (jogoFinalizado)
            return;

        if (fonteAudio != null)
            fonteAudio.Play();

        if (disco != null)
        {
            disco.SendMessage(
                "ReiniciarDisco",
                null,
                SendMessageOptions.RequireReceiver
            );
        }

        jogoFinalizado = true;
    }

    // =============================================================
    // LIMPEZA
    // =============================================================

    void OnDestroy()
    {
        if (texturaRosa != null)
            Destroy(texturaRosa);

        if (texturaAzul != null)
            Destroy(texturaAzul);

        if (texturaBranca != null)
            Destroy(texturaBranca);
    }
}