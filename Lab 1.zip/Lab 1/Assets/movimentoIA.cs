using UnityEngine;

public class MovimentoIA : MonoBehaviour
{
    public Transform disco;
    public float velocidade = 5f;
    public float limiteY = 4.4f;
    public float limiteMinimoY = 0.5f;
    public float limiteX = 2.25f;
    public AudioSource fonteAudio;

    private Rigidbody2D corpo;

    void Start()
    {
        corpo = GetComponent<Rigidbody2D>();
        fonteAudio = GetComponent<AudioSource>();
    }

    void OnCollisionEnter2D(Collision2D colisao)
    {
        if (fonteAudio != null)
            fonteAudio.Play();
    }

    void Update()
    {
        if (disco == null)
            return;

        if (corpo.position.y > limiteY)
            corpo.position = new Vector2(corpo.position.x, limiteY);
        else if (corpo.position.y < limiteMinimoY)
            corpo.position = new Vector2(corpo.position.x, limiteMinimoY);

        if (corpo.position.x < -limiteX)
            corpo.position = new Vector2(-limiteX, corpo.position.y);
        else if (corpo.position.x > limiteX)
            corpo.position = new Vector2(limiteX, corpo.position.y);

        if (disco.position.y > limiteMinimoY)
        {
            Vector2 alvo = new Vector2(disco.position.x, 3f);
            float distancia = Vector2.Distance(corpo.position, alvo);

            if (distancia > 0.1f)
                corpo.linearVelocity = (alvo - corpo.position).normalized * velocidade;
            else
                corpo.linearVelocity = Vector2.zero;
        }
        else
        {
            corpo.linearVelocity = (disco.position - transform.position).normalized * velocidade;
        }
    }
}
