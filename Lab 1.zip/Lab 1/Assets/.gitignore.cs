[Ll]ibrary/
[Tt]emp/
[Oo]bj/
[Bb]uild/
[Bb]uilds/
[Ll]ogs/
[Uu]ser[Ss]ettings/

MemoryCaptures/
Recordings/

.vs/
.idea/

*.csproj
*.unityproj
*.sln
*.suo
*.user
*.userprefs

.DS_Store
Thumbs.db

sysinfo.txt