using UnityEngine;

public class ParedesLaterais : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D informacaoColisao)
    {
        if (informacaoColisao.CompareTag("Ball"))
        {
            string nomeParede = transform.name;
            GerenciadorDoJogo.MarcarPonto(nomeParede);
            informacaoColisao.gameObject.SendMessage("ReiniciarJogo", null, SendMessageOptions.RequireReceiver);
        }
    }
}
